product-price = 10.5

print(product-price)