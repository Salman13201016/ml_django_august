from django.apps import AppConfig


class HospitalCategoryConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "hospital_category"
